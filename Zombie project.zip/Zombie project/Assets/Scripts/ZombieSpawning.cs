﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ZombieSpawning : MonoBehaviour {

    public GameObject zombie;
    public GameObject spawn1,spawn2, spawn3, spawn4;
   public int zombieCount;
    public int zombieMax;
    public float time;
    bool zombiealive;

	void Start () {
        time = 0;
        zombieCount = 0;
        zombieMax = 1;
        zombiealive = zombie.GetComponent<ZombieBehaviour>().isAlive;
	}


    void LateUpdate()
    {
        time += Time.deltaTime;
        if (time < .03)
            zombieMax++;
        if(time>10&&time<60*5)
        {
            if (time % 10 > 0 && time % 10 < .015)
                    zombieMax++;
        }
        if(time>=60*5)
        {
            if(time%10>0 && time % 10 <.01)
            {
                zombieMax = zombieMax * 2;
            }
        }
        if (time % 5 < 1 && time % 5 > .6)
        {

            if (zombieCount < zombieMax)
            {
                float ranNum = Random.Range(0, 4);
                
                if (ranNum % 4 == 0)
                {
                    Vector3 range = new Vector3(Random.Range(spawn1.transform.position.x, spawn1.transform.position.x + 10),1,Random.Range(spawn1.transform.position.y,spawn1.transform.position.y+10));
                    Instantiate(zombie, range, Quaternion.identity);
                }
                else if (ranNum % 4 == 1)
                {
                    Vector3 range = new Vector3(Random.Range(spawn2.transform.position.x, spawn2.transform.position.x + 10), 1, Random.Range(spawn2.transform.position.y, spawn2.transform.position.y + 10));
                    Instantiate(zombie, range, Quaternion.identity);
                }
                else if (ranNum % 4 == 2)
                {
                    Vector3 range = new Vector3(Random.Range(spawn3.transform.position.x, spawn3.transform.position.x + 10), 1, Random.Range(spawn3.transform.position.y, spawn3.transform.position.y + 10));
                    Instantiate(zombie, range, Quaternion.identity);
                }
                else if (ranNum % 4 == 3)
                {
                    Vector3 range = new Vector3(Random.Range(spawn4.transform.position.x, spawn4.transform.position.x + 10), 1, Random.Range(spawn4.transform.position.y, spawn4.transform.position.y + 10));
                    Instantiate(zombie, range, Quaternion.identity);
                }
            }

        }
        
    }

    public void addCount()
    {
        zombieCount++;
    }

    public void reduceCount()
    {
        zombieCount--;
    }
}
