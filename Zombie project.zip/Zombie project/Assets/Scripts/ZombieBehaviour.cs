﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.AI;

public class ZombieBehaviour : MonoBehaviour {

    public bool isAlive,isWalking,isAttacking;
    int state;//0 idle, 1 spawning, 2 walking, 3 attacking, 4 dieing
    public GameObject player;
    public GameObject weapon;
    public GameObject zombieSpawn;
    Animator anim;
    double attackRange = 3;
    NavMeshAgent agent;

	void Start () {
        isAlive = true;
        isWalking = false;
        isAttacking = false;
        anim = GetComponent<Animator>();
        state = 1;//sets to spawn
        agent = GetComponent<NavMeshAgent>();
        zombieSpawn.GetComponent<ZombieSpawning>().addCount();
	}
	
	
	void LateUpdate () {
        if (zombieSpawn.GetComponent<ZombieSpawning>().time < .05)
            isAlive = false;
        if (isAlive)//checks if alive
        {
            if (state == 1)//sets to moving after spawn
            {
                state = 2;
                isWalking = true;

            }
            if (state == 2)
            {
                anim.SetBool("isWalking", isWalking);
                anim.SetBool("isAttacking", isAttacking);
                transform.LookAt(player.transform);
                agent.destination = player.transform.position;
                agent.isStopped = false;
                if (Vector3.Distance(transform.position, player.transform.position) <= attackRange)
                {
                    state = 3;//sets to attack
                    isWalking = false;
                    isAttacking = true;
                }
            }
            if (state == 3)
            {
                anim.SetBool("isWalking", isWalking);
                anim.SetBool("isAttacking", isAttacking);
                agent.destination = transform.position;
                agent.isStopped = false;
                if (Vector3.Distance(transform.position, player.transform.position) > attackRange)//when player leaves attack range
                {
                    state = 2;//sets back to moving
                    isAttacking = false;
                    isWalking = true;
                }
            }
            if (Vector3.Distance(transform.position, weapon.transform.position) <= 1)//triggers when weapon gets to close
            {
                state = 4;//sets to dieing
                agent.destination = transform.position;
                isWalking = false;
                isAttacking = false;
                isAlive = false;//shows as dead
                Kill();

            }


        }
	}
    public void Kill()
    {
        if (isAlive==false)
        {
            anim.SetBool("isWalking", isWalking);
            anim.SetBool("isAttacking", isAttacking);
            anim.SetBool("isAlive", isAlive);
            gameObject.GetComponent<NavMeshAgent>().isStopped = true;
            zombieSpawn.GetComponent<ZombieSpawning>().reduceCount();
            gameObject.GetComponent<Rigidbody>().isKinematic = true;
            Destroy(gameObject, 0);
        }
    }
}
